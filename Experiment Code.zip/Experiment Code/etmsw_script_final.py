import random
import math
import os
import csv
import sys
from psychopy import visual, core, event
from psychopy.data import ExperimentHandler
import pandas as pd

# Get the directory of the current script
script_dir = os.path.dirname(__file__)
# Append the relative path to pylinkwrapper2
pylinkwrapper_dir = os.path.join(script_dir, 'pylinkwrapper')
sys.path.append(pylinkwrapper_dir)
import pylinkwrapper

# Function to generate a random 6-digit number (to name participant file)
def generate_random_number():
    return str(random.randint(100000, 999999))

random_number = generate_random_number()

# Function to display instructions and wait for the participant to click "NEXT"
def display_instructions(text):
    instructions = visual.TextStim(win, text=text, pos=(0, 0.2), wrapWidth=40)
    button_width = 4
    button_height = 2
    button_pos = (0, -10)  # Adjust position as needed
    next_button = visual.Rect(win, width=button_width, height=button_height, pos=button_pos, fillColor='black')
    next_text = visual.TextStim(win, text="NEXT", pos=button_pos, color='white', height=1)
    mouse = event.Mouse(win=win)

    while True:
        instructions.draw()
        next_button.draw()
        next_text.draw()
        win.flip()
        if mouse.isPressedIn(next_button):
            break
        if 'escape' in event.getKeys():
            core.quit()  # Exit the program if 'escape' key is pressed


# Initialize Experiment Window
win = visual.Window(size=(2560, 1440), fullscr=True, screen=0, allowGUI=True,
    monitor=u'myCustomMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, units = 'deg')

fixation = visual.TextStim(win, text='+', pos=(0, 0))
mouse = event.Mouse(win=win)

#Set the desired data directory
data_dir = r"C:\Users\eyetrack\Box\etmsw_data"
if not os.path.exists(data_dir):
    os.makedirs(data_dir)

#Generate a unique file name
file_base_name = str(random_number)

#Full path for saving behavioral data
file_path = os.path.join(data_dir, file_base_name)

#Initiate eye-tracker using only the base name (not full path!)
tracker = pylinkwrapper.connect(win, file_base_name)

#Setup ExperimentHandler with full file path
exp = ExperimentHandler(
    name='ET Experiment',
    version='1.0',
    saveWideText=True,
    dataFileName=file_path  # full path to save .csv and .log files
)

# Calibrate eye-tracker
tracker.calibrate(cnum=13, paval = 1000, button_function='accept_target_fixation')

# Start the Timer
experiment_start_time = core.getTime()

def practice_trial():
    target_object = "Mug"  # Example target object
    is_target_present = True  # You can set this to False for an absent target practice
    image_file = "example_scene.png"  # Example image file for the practice trial

    # Screen 1: Fixation cross for 1 second
    mouse.setVisible(False)
    fixation.draw()
    win.flip()
    if tracker:
        tracker.sendMessage('START_FIXCHECK')
        tracker.setStatus('Practice Fixation Check')
        tracker.fixCheck(size=4.5, ftime=0.5, button='r')
        tracker.sendMessage('END_FIXCHECK')
        tracker.setTrialResult()


    # Screen 2: Target word display for 1.5 seconds
    target_text = visual.TextStim(win, text=target_object, pos=(0, 1), wrapWidth=40)
    fixation.draw()
    if tracker:
        tracker.recordON()  # Start recording eye data
        tracker.setStatus('Practice Cue Screen')
        tracker.sendMessage('Practice_Cue_Screen')
    target_text.draw()
    win.flip()
    core.wait(1.5)
    mouse.setVisible(False)

    # Screen 3: Fixation cross for 1 second
    fixation.draw()
    win.flip()
    core.wait(1)
    mouse.setVisible(False)
    if tracker:
        tracker.setTrialResult()

    # Screen 4: Image display until space bar is pressed or 5 seconds have passed
    mouse.setVisible(False)
    image_path = os.path.join(os.path.dirname(__file__), "spatial_judgement_stims", image_file)
    if not os.path.exists(image_path):
        print(f"Error: Image file {image_path} does not exist.")
        exp.addData('error', f"Image file {image_path} not found.")
        exp.nextEntry()
        win.close()
        core.quit()
    image_stim = visual.ImageStim(win, image=image_path, pos=(0, 0))
    if tracker:
        tracker.recordON()  # Start recording eye data
        tracker.setStatus('Practice Scene Screen')
        tracker.sendMessage('Practice_Scene_Screen')
    image_stim.draw()
    win.flip()
    image_start_time = core.getTime()


    # Wait for P or A key response (5 sec timeout)
    keys = event.waitKeys(maxWait=5, keyList=['left', 'right', 'escape'], timeStamped=True)
    
    if keys:  # Check if a valid key was pressed
        response_key = keys[0][0]
        reaction_time = keys[0][1]- image_start_time
    else:  # 20 seconds passed without space bar press
        reaction_time = 'NA'  # Record 'NA' for timeout
    if keys and keys[0][0] == 'escape':  # Escape key exits experiment
        win.close()
        core.quit()

    
        # Correct response check
        if is_target_present and response_key == 'left':
            response_correct = 1  # Correct response
        elif not is_target_present and response_key == 'right':
            response_correct = 1  # Correct response
        else:
            response_correct = 0  # Incorrect response
    if tracker:
        tracker.setTrialResult()


    # Screen 5: Blank screen for 750 ms
    mouse.setVisible(False)
    win.flip()
    core.wait(0.75)


    # Memory Probe Section: Using the rectangle image
    mouse.setVisible(True)
    rectangle_image_path = os.path.join(os.path.dirname(__file__), "spatial_judgement_stims", "rectangle_image.png")
    if not os.path.exists(rectangle_image_path):
        print(f"Error: Rectangle image file {rectangle_image_path} does not exist.")
        win.close()
        core.quit()
    
    if tracker:
        tracker.recordON()  # Start recording eye data
        tracker.setStatus('Practice Probe Screen')
        tracker.sendMessage('Practice_Probe_Screen')

    rectangle_image = visual.ImageStim(win, image=rectangle_image_path, pos=(0, 0))
    next_button = visual.Rect(win, width=4, height=2, pos=(0, -13), fillColor='black')
    next_text = visual.TextStim(win, text="NEXT", pos=(0, -13), color='white', height=1)
   
            
    # Wait for mouse click inside the rectangle or on the "Next" button
    mouse_click = False
    while not mouse_click:
        rectangle_image.draw()
        next_button.draw()
        next_text.draw()
        win.flip()

        mouse_pos = mouse.getPos()
        if rectangle_image.contains(mouse_pos) and mouse.isPressedIn(rectangle_image):
            mouse_click = True
        elif next_button.contains(mouse_pos) and mouse.isPressedIn(next_button):
            mouse_click = True
    if tracker:
        tracker.setTrialResult()
    
    # Screen 5: Blank screen for 750 ms
    win.flip()
    core.wait(0.75)

def trial_randomization():
    # Load trial data
    file_path = os.path.join(os.path.dirname(__file__), "trial_randomization_sheet.csv")
    if not os.path.exists(file_path):
        print(f"Error: Trial randomization sheet {file_path} not found.")
        win.close()
        core.quit()

    # Load the CSV
    trial_data = pd.read_csv(file_path)

    # Debugging: Check CSV columns and unique values
    print("Columns in trial_data:", trial_data.columns)
    print("Unique target_present values:", trial_data['target_present'].unique())
    print("Unique scene_visibility values:", trial_data['scene_visibility'].unique())
    print("Unique target_validity values:", trial_data['target_validity'].unique())

    # Ensure unique scene-target combinations and shuffle the data
    trial_data = trial_data.drop_duplicates(
        subset=['scene_type', 'scene_number', 'target_object', 'target_validity', 'scene_visibility', 'target_present'])


    # Setup constraints
    total_present_trials = 160  # Total present trials
    total_absent_trials = 40  # Total absent trials
    present_trials_per_condition = total_present_trials // 4  # 40 per present condition
    absent_trials_per_condition = total_absent_trials // 2  # 20 high, 20 low absent

    # Split data into Present and Absent Trials based on `target_present`
    present_trials = trial_data[trial_data['target_present'] == True]  # Present trials
    absent_trials = trial_data[trial_data['target_present'] == False]  # Absent trials

    # Debugging: Check sizes of Present and Absent trials
    print(f"Total Present Trials: {present_trials.shape[0]} trials")
    print(f"Total Absent Trials: {absent_trials.shape[0]} trials")
    
    # Track used combinations to ensure uniqueness across all conditions
    used_combinations = set()

    def sample_unique(df, n, used_set):
        unique_rows = []
        df = df.sample(frac=1)  # Shuffle input df
        for _, row in df.iterrows():
            combo = (row['scene_type'], row['scene_number'], row['target_object'])
            if combo not in used_set:
                used_set.add(combo)
                unique_rows.append(row)
            if len(unique_rows) == n:
                break
        if len(unique_rows) < n:
            print(f"Warning: Only {len(unique_rows)} unique trials could be selected (requested {n})")
        return pd.DataFrame(unique_rows)

    # Further split Present Trials into 4 Conditions based on `scene_visibility` and `target_validity`
    high_valid_present = present_trials[
        (present_trials['scene_visibility'] == 'high') & (present_trials['target_validity'] == "valid")]
    low_valid_present = present_trials[
        (present_trials['scene_visibility'] == 'low') & (present_trials['target_validity'] == "valid")]
    high_invalid_present = present_trials[
        (present_trials['scene_visibility'] == 'high') & (present_trials['target_validity'] == "invalid")]
    low_invalid_present = present_trials[
        (present_trials['scene_visibility'] == 'low') & (present_trials['target_validity'] == "invalid")]

    # Debugging: Check sizes of Present Trial subsets
    print(f"High Valid Present Trials: {high_valid_present.shape[0]} trials")
    print(f"Low Valid Present Trials: {low_valid_present.shape[0]} trials")
    print(f"High Invalid Present Trials: {high_invalid_present.shape[0]} trials")
    print(f"Low Invalid Present Trials: {low_invalid_present.shape[0]} trials")

    # Further split Absent Trials into High and Low Visibility
    high_absent = absent_trials[absent_trials['scene_visibility'] == 'high']
    low_absent = absent_trials[absent_trials['scene_visibility'] == 'low']

    # Debugging: Check sizes of Absent Trial subsets
    print(f"High Absent Trials: {high_absent.shape[0]} trials")
    print(f"Low Absent Trials: {low_absent.shape[0]} trials")

    # Randomly sample trials for each condition
    high_valid_sample = sample_unique(high_valid_present, present_trials_per_condition, used_combinations)
    low_valid_sample = sample_unique(low_valid_present, present_trials_per_condition, used_combinations)
    high_invalid_sample = sample_unique(high_invalid_present, present_trials_per_condition, used_combinations)
    low_invalid_sample = sample_unique(low_invalid_present, present_trials_per_condition, used_combinations)
    high_absent_sample = sample_unique(high_absent, absent_trials_per_condition, used_combinations)
    low_absent_sample = sample_unique(low_absent, absent_trials_per_condition, used_combinations)

    # Combine all samples
    participant_trials = pd.concat([
        high_valid_sample,
        low_valid_sample,
        high_invalid_sample,
        low_invalid_sample,
        high_absent_sample,
        low_absent_sample
    ]).reset_index(drop=True)

    # Shuffle the final dataset
    participant_trials = participant_trials.sample(frac=1).reset_index(drop=True)

    # Return the randomized trials
    return participant_trials

# Load the randomized trial data
trial_data = trial_randomization()

def trial_block():
    all_indices = list(trial_data.index)
    used_indices = set()
    total_trials = len(all_indices)
    halfway_point = total_trials // 2  # Halfway point for the break
    trial_counter = 1

    while len(used_indices) < len(all_indices):
        selected_index = random.choice([idx for idx in all_indices if idx not in used_indices])
        selected_row = trial_data.loc[selected_index]

        target_object = selected_row['target_object']
        target_present = selected_row['target_present']
        image_file = selected_row['image_file']
        scene_type = selected_row['scene_type']
        scene_visibility = selected_row['scene_visibility']
        target_validity = selected_row['target_validity']
        target_present = selected_row['target_present']

        # Screen 1: Fixation cross for 1 second
        mouse.setVisible(False)
        fixation.draw()
        win.flip()
        if tracker:
            tracker.setStatus(f'Fix Check Screen {trial_counter}')
            tracker.fixCheck(size=4.5, ftime=0.5, button='r')
            tracker.sendMessage(f'START_FIXCHECK_{trial_counter}')
            tracker.sendMessage(f'END_FIXCHECK_{trial_counter}')
            tracker.setTrialID(trial_counter)
            tracker.setTrialResult()
           
        
        # Screen 2: Target word display for 1.5 seconds
        target_text = visual.TextStim(win, text=target_object, pos=(0, 1), wrapWidth=40)
        fixation.draw()
        if tracker:
            tracker.recordON()
            tracker.setStatus(f'Cue Screen {trial_counter}')
            tracker.sendMessage(f'Cue_Screen_{trial_counter}')
        target_text.draw()
        mouse.setVisible(False)
        win.flip()
        core.wait(1.5)

        # Screen 3: Fixation cross for 1 second
        fixation.draw()
        win.flip()
        core.wait(1)
        mouse.setVisible(False)
        if tracker:
            tracker.setTrialResult()

        # Screen 4: Image display for up to 5 seconds, waiting for key press
        mouse.setVisible(False)  # Hide the mouse during scene presentation
        image_path = os.path.join(os.path.dirname(__file__), "spatial_judgement_stims", image_file)
        if not os.path.exists(image_path):
            print(f"Error: Image file {image_path} does not exist.")
            exp.addData('error', f"Image file {image_path} not found.")
            exp.nextEntry()
            win.close()
            core.quit()
        image_stim = visual.ImageStim(win, image=image_path, pos=(0, 0))
        if tracker:
            tracker.recordON()  # Start recording eye data
            tracker.setStatus(f'Scene Screen {trial_counter}')
            tracker.sendMessage(f'Scene_Screen_{trial_counter}')
        image_stim.draw()
        win.flip()

        keys = event.waitKeys(maxWait=5, keyList=['left', 'right', 'escape'], timeStamped=True)

        if keys and keys[0][0] == 'escape':  # Escape key exits experiment
            win.close()
            core.quit()
        elif keys:
            response_key = keys[0][0]
            reaction_time = keys[0][1]
            is_target_present = selected_row['target_present']
            if is_target_present and response_key == 'left':
                response_correct = 1  # Correct response
            elif not is_target_present and response_key == 'right':
                response_correct = 1  # Correct response
            else:
                response_correct = 0  # Incorrect response
            if tracker:
                tracker.setTrialResult()
        else:
            reaction_time = 'NA'
            response_correct = 'NA'
            if tracker:
                tracker.setTrialResult()
        
        # Screen 5: Memory Probe Section
        mouse.setVisible(True)  # Re-enable the mouse for the memory probe
        rectangle_image_path = os.path.join(os.path.dirname(__file__), "spatial_judgement_stims", "rectangle_image.png")
        if not os.path.exists(rectangle_image_path):
            print(f"Error: Rectangle image file {rectangle_image_path} does not exist.")
            win.close()
            core.quit()
            
        rectangle_image = visual.ImageStim(win, image=rectangle_image_path, pos=(0, 0))
        next_button = visual.Rect(win, width=4, height=2, pos=(0, -13), fillColor='black')
        next_text = visual.TextStim(win, text="NEXT", pos=(0, -13), color='white', height=1)
        
        if tracker:
            tracker.recordON()  # Start recording eye data
            tracker.setStatus(f'Probe Screen {trial_counter}') 
            tracker.sendMessage(f'Probe_Screen_{trial_counter}')
            
        # Wait for mouse clicks during the memory probe
        mouse_click = False
        while not mouse_click:
            rectangle_image.draw()
            next_button.draw()
            next_text.draw()
            win.flip()

            mouse_pos = mouse.getPos()
            if rectangle_image.contains(mouse_pos) and mouse.isPressedIn(rectangle_image):
                mouse_click = True
                click_type = 'rectangle'
                if tracker:
                    tracker.setTrialResult()  
            elif next_button.contains(mouse_pos) and mouse.isPressedIn(next_button):
                mouse_click = True
                click_type = 'next'
                if tracker:
                    tracker.setTrialResult()  
                    
        # Screen 6: Fixation cross for 1 second
        mouse.setVisible(False)
        fixation.draw()
        if tracker:
            tracker.recordON()
            tracker.setStatus(f'Wait Screen {trial_counter}')
            tracker.sendMessage(f'Wait_Screen_{trial_counter}')
        win.flip()
        core.wait(1)
        if tracker:
            tracker.setTrialResult()



        # Get screen and stim info
        screen_width, screen_height = win.size
        stim_width, stim_height = image_stim.size
        stim_x, stim_y = image_stim.pos
        experiment_end_time = core.getTime()
        experiment_duration = experiment_end_time - experiment_start_time
        formatted_duration = f"{experiment_duration:.3f}"
        exp.addData('experiment_duration', formatted_duration)
            
        # Save trial data
        exp.addData('screen_width', screen_width)
        exp.addData('screen_height', screen_height)
        exp.addData('stim_width', stim_width)
        exp.addData('stim_height', stim_height)
        exp.addData('stim_pos_x', stim_x)
        exp.addData('stim_pos_y', stim_y)
        exp.addData('scene_type', scene_type)
        exp.addData('target_object', target_object)
        exp.addData('target_present', target_present)
        exp.addData('image_file', image_file)
        exp.addData('scene_visibility', scene_visibility)
        exp.addData('target_validity', target_validity)
        exp.addData('target_present', target_present)
        exp.addData('rt', reaction_time)
        exp.addData('accuracy', response_correct)
        exp.addData('row_index', selected_index)
        exp.addData('memory_probe_click', click_type)
        exp.addData('click_x', mouse_pos[0])
        exp.addData('click_y', mouse_pos[1])
        exp.addData('trial', trial_counter)
        exp.nextEntry()

        trial_counter += 1  # Increment trial counter
        used_indices.add(selected_index)

        # Show a break screen if at the halfway point
        if trial_counter == halfway_point:
            display_instructions(
                "You are halfway through the task! Take a short break.\n\nWhen you are ready, click 'NEXT' to continue."
            )

    # Show finished screen
    display_instructions(
        "You have finished the experiment!\n\nThank you for participating.\n\nClick 'NEXT' to close the experiment.")

        # Turn off tracker and save final data
    if tracker:
        tracker.recordOFF()
        tracker.endExperiment(r"C:\Users\eyetrack\Desktop\etmsw_416\etmsw (1)\etmsw\Data")  # <- inside this block

    mouse.setVisible(True)  # Ensure the mouse is visible at the end of the experiment

    exp.nextEntry()
    win.close()
    core.quit()

# Call the trial block to execute the functionality
display_instructions(
    "In the following task your goal will be to search for a 'target' object in images of indoor scenes and indicate where that object appeared.\n\nClick 'NEXT' to continue.")
display_instructions(
    "At the start of each trial, you will be asked to maintain your fixation on a central fixation cross.\n\nClick 'NEXT' to continue.")
display_instructions(
    "You will then see the name of your target object appear on your screen (e.g., Clothing Iron).\n\nClick 'NEXT' to continue.")
display_instructions(
    "On the following screen, you will be shown an image of an indoor scene (e.g.,a laundry room). \n\n Quickly search that image for your target object. \n\n Your goal is to indicate whether your target object was present in that scene or not! \n\n If it was, press the 'Left' arrow key on your keyboard. \n\n If it was not (i.e., absent), then press the 'Right' arrow key. \n\nClick 'NEXT' to continue.")
display_instructions(
    "After you make your response, you will see a rectangle the size of the previous scene. \n\n If you found the object in the previous scene, use your mouse to click inside the rectangle where you remember the object being. \n\n If the object was absent from the scene just click the 'NEXT' button to move on to your next target. \n\nClick 'NEXT' to continue.")
display_instructions(
    "Are you ready to practice? \n\n Lets try one before you begin the main task! \n\nClick 'NEXT' to continue.")

# Run the practice trial
practice_trial()

# Add a transition screen for readiness confirmation
display_instructions("Are you ready to begin? \n\n Rememeber, try to find your target object as quickly as possible before time runs out. If your target is present press the 'Left' arrow key, if it was absent press the 'Right' arrow key. \n\n If present, don't forget to indicate exactly where it was! \n NOTE: Don't forget to put your hand back on the keyboard after using the mouse. \n\n Good luck! \n\nClick 'NEXT' to start the main task.")

# Countdown screen before the real task
countdown_text = visual.TextStim(win, text="You are about to begin the task.", pos=(0, 0.2), wrapWidth=40)
for i in range(5, 0, -1):
    countdown_text.text = f"You are about to begin the task.\n\n{str(i)}..."
    countdown_text.draw()
    win.flip()
    core.wait(1)  # Wait for 1 second

# Run the main trial block
trial_block()
